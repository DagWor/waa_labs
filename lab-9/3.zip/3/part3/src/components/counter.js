import React, { useState } from "react"

export function Counter({ number }) {
    const [counter, setCounter] = useState(0);
    const increment = () => {
        setCounter(counter + number);
    }
    const decrement = () => {
        setCounter(counter - number);
    }

    return (
        <div>
            <h5> &emsp; &emsp; {counter} </h5>
            <button onClick={increment}> + {number} </button> &emsp;
            <button onClick={decrement}> - {number} </button>
        </div>
    )
}