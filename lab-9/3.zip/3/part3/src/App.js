import './App.css';
import { Counter } from './components/counter';
function App() {
  return (
    <div>
      <div className="counter-container">
        <Counter number={1} />
        <Counter number={3} />
      </div>
      <div className='counter-container'>
        <Counter number={5} />
        <Counter number={8} />
      </div>
    </div>
  );
}
export default App;