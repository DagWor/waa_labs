import React from "react"

export function Button({ label, onClick }) {
    return (
        <div>
            <button onClick={onClick}> Say {label} </button>
        </div>
    )
}