import './App.css';
import { Button } from './components/button';
function App() {
  const handleButtonClick = (message)=>{
    alert(message);
  }
  return (
    <div>
      <Button label="Hello From Button 1" onClick={e=>handleButtonClick(e.target.innerHTML)}/>
      <Button label="Welcome From Button 2" onClick={e=>handleButtonClick(e.target.innerHTML)}/>
      <Button label="Hi From Button 2" onClick={e=>handleButtonClick(e.target.innerHTML)}/>
      <Button label="Goodbye From Button 2" onClick={e=>handleButtonClick(e.target.innerHTML)}/>
    </div>
  );
}
export default App;