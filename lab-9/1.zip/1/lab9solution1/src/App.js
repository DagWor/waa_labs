import './App.css';
function App() {
  return (
    <div>
      <header>
        <p>
          Hello world
        </p>
      </header>
    </div>
  );
}

export default App; 
