import React from "react"

export function Counter({ value,factor,onIncrement,onDecrement }) {
    return (
        <div>
            <> &emsp; &emsp; {value} </> <br/>
            <button onClick={onIncrement}> + {factor} </button> &emsp;
            <button onClick={onDecrement}> - {factor} </button>
        </div>
    )
}