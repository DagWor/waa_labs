import { useState } from 'react';
import './App.css';
import { Counter } from './components/counter';

function App() {
  const [value, setValue] = useState(0);
  const onIncrement = (factor) => {
    setValue(value + factor);
  }
  const onDecrement = (factor) => {
    setValue(value - factor);
  }
  return (
    <div>
      <h3> &emsp;&emsp; {value} </h3>
      <div className='counter-container'>
        <Counter value={value} factor={1} onIncrement={() => onIncrement(1)} onDecrement={() => onDecrement(1)} />
        <Counter value={value} factor={3} onIncrement={() => onIncrement(3)} onDecrement={() => onDecrement(3)} />
      </div>
      <div className='counter-container'>
        <Counter value={value} factor={5} onIncrement={() => onIncrement(5)} onDecrement={() => onDecrement(5)} />
        <Counter value={value} factor={8} onIncrement={() => onIncrement(8)} onDecrement={() => onDecrement(8)} />
      </div>
    </div>
  );
}
export default App;