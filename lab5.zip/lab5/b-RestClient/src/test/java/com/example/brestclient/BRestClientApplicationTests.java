package com.example.brestclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BRestClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
