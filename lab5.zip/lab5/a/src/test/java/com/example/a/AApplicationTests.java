package com.example.a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AApplicationTests {

    @Test
    void contextLoads() {
    }

}
