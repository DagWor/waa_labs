package edu.miu.lab.controllers;

import edu.miu.lab.exceptions.AccountNotFoundException;
import edu.miu.lab.models.Account;
import edu.miu.lab.models.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Controller
public class BankController {
    private final Map<String, Account> accounts = new HashMap<>();

    public BankController() {
        accounts.put("9781593279509", new Account("9781593279509", "Marijn Haverbeke", 0));
        accounts.put("9781491943533", new Account("9781491943533", "Nicolás Bevacqua", 0));
        accounts.put("9781484242216", new Account("9781484242216", "Caitlin Sadowski, Thomas Zimmermann", 0));
    }

    @PostMapping("/accounts")
    public ResponseEntity<?> createAccount(@RequestBody Account account) {
        this.accounts.put(account.getAccountNumber(), account);
        return new ResponseEntity<>(account, HttpStatus.CREATED);
    }

    @DeleteMapping("/accounts/{accountNumber}")
    public ResponseEntity<?> removeAccount(@PathVariable("accountNumber") String accountNumber) {
        Account account = this.accounts.get(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account with account no. " + accountNumber + " not found");
        }
        accounts.remove(accountNumber);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/accounts/{accountNumber}")
    public ResponseEntity<?> getAccount(@PathVariable("accountNumber") String accountNumber) {
        Account account = this.accounts.get(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account with account no. " + accountNumber + " not found");
        }
        return new ResponseEntity<>(account, HttpStatus.OK);
    }

    @PostMapping("/accounts/deposit")
    public ResponseEntity<?> deposit(String accountNumber, Double amount) throws AccountNotFoundException {
        Transaction transaction = new Transaction(amount, new Date());
        Account account = this.accounts.get(accountNumber);
        if (account == null)
            throw new AccountNotFoundException("Account with account no. " + accountNumber + " not found");
        account.addTransactions(transaction);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/accounts/withdraw")
    public ResponseEntity<?> withdraw(String accountNumber, Double amount) throws AccountNotFoundException {
        Transaction transaction = new Transaction(-amount, new Date());
        Account account = this.accounts.get(accountNumber);
        if (account == null)
            throw new AccountNotFoundException("Account with account no. " + accountNumber + " not found");
        account.addTransactions(transaction);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
