package edu.miu.lab.controllers;

import edu.miu.lab.exceptions.BookNotFoundException;
import edu.miu.lab.models.Book;
import edu.miu.lab.models.Books;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Controller
public class BookController {
    private final Map<String, Book> books = new HashMap<>();

    public BookController() {
        books.put("9781593279509", new Book("9781593279509", "Marijn Haverbeke", "A Modern Introduction to Programming", 35.99));
        books.put("9781491943533", new Book("9781491943533", "Nicolás Bevacqua", "Practical Modern JavaScript", 99.99));
        books.put("9781484242216", new Book("9781484242216", "Caitlin Sadowski, Thomas Zimmermann", "Rethinking Productivity in Software Engineering", 219.99));
    }

    @PostMapping("/books")
    public ResponseEntity<?> addBook(@RequestBody Book book) {
        this.books.put(book.getIsbn(), book);
        return new ResponseEntity<>(book, HttpStatus.CREATED);
    }

    @PutMapping("/books/{isbn}")
    public ResponseEntity<?> updateBook(@PathVariable("isbn") String isbn, @RequestBody Book book) {
        this.books.put(isbn, book);
        return ResponseEntity.ok(null);
    }

    @DeleteMapping("/books/{isbn}")
    public ResponseEntity<?> deleteBook(@PathVariable String isbn) throws BookNotFoundException {
        Book book = this.books.get(isbn);
        if (book == null) {
            throw new BookNotFoundException("Book with isbn " + isbn + " not found");
        }
        books.remove(isbn);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/books/{isbn}")
    public ResponseEntity<?> getBook(@PathVariable String isbn) throws BookNotFoundException {
        Book book = this.books.get(isbn);
        if (book == null) {
            throw new BookNotFoundException("Book with isbn " + isbn + " not found");
        }
        return new ResponseEntity<>(book, HttpStatus.OK);
    }

    @GetMapping("/books")
    public ResponseEntity<?> getAllBooks() {
        Books books = new Books(this.books.values());
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @GetMapping("/books/search")
    public ResponseEntity<?> searchBooks(@RequestParam String author) {
        Optional<Book> book = this.books.values().stream().filter(b -> b.getAuthor().equals(author)).findAny();
        if (book.isPresent())
            return new ResponseEntity<>(book.get(), HttpStatus.OK);
        return new ResponseEntity<>(new BookNotFoundException("Book with author " + author + " not found"), HttpStatus.NOT_FOUND);
    }
}
