import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css';
import { Part3 } from './components/part3';
import { Part4 } from './components/part4';
import { Final } from './components/final';

export default function App(){
  return(
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Part3/>} />
        <Route path="/part4" element={<Part4/>} />
        <Route path="/final" element={<Final/>} />
      </Routes>
    </BrowserRouter>
  )
}
