import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import { Part1 } from './pages/part1';
import { Part2 } from './pages/part2';
import { Part3 } from './pages/part3';
import { Review } from './pages/review';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Part1 />} />
        <Route path="/part2" element={<Part2 />} />
        <Route path="/part3" element={<Part3 />} />
        <Route path="/review" element={<Review />} />
      </Routes>
    </BrowserRouter>
  );
}
export default App; 
