package com.example.book;

import com.example.book.models.Book;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItems;

@SpringBootTest
class BookApplicationTests {

    @BeforeAll
    public static void setup() {
        RestAssured.port = 8080;
        RestAssured.baseURI = "http://localhost";
        RestAssured.basePath = "/books";
    }

    @Test
    public void testGetAllBooks() {
        RestAssured.given()
                .when()
                .get("")
                .then()
                .contentType(ContentType.JSON)
                .and()
                .statusCode(200)
                .and()
                .body("books.title", hasItems("A Modern Introduction to Programming", "Practical Modern JavaScript"))
                .body("books.isbn", hasItems("9781593279509", "9781491943533"));
    }

    @Test
    public void testGetOneBook() {
        RestAssured.given()
                .when()
                .get("/9781593279509")
                .then()
                .contentType(ContentType.JSON)
                .and()
                .statusCode(200)
                .and()
                .body("isbn", equalTo("9781593279509"))
                .body("title", equalTo("A Modern Introduction to Programming"))
                .body("author", equalTo("Marijn Haverbeke"));
    }

    @Test
    public void testAddBook() {
        Book newBook = new Book("231314914", "Test User", "Software Architecture", 49.9);
        RestAssured.given()
                .contentType("application/json")
                .body(newBook)
                .when()
                .post("")
                .then()
                .statusCode(201)
                .and()
                .body("isbn", equalTo(newBook.getIsbn()));
    }

    @Test
    public void testDeleteBook() {
        Book newBook = new Book("231314914", "Test User", "Software Architecture", 49.9);
        RestAssured.given()
                .contentType("application/json")
                .body(newBook)
                .when()
                .post("")
                .then()
                .statusCode(201);
        RestAssured.given()
                .when()
                .delete("/" + newBook.getIsbn())
                .then()
                .statusCode(204);
    }

    @Test
    public void testUpdateBook() {
        // Add new book
        Book newBook = new Book("231314914", "Test User", "Software Architecture", 49.9);
        RestAssured.given()
                .contentType("application/json")
                .body(newBook)
                .when()
                .post("")
                .then()
                .statusCode(201);

        // Update the book
        newBook.setPrice(59.99);
        RestAssured.given()
                .contentType("application/json")
                .body(newBook)
                .put("/" + newBook.getIsbn())
                .then()
                .statusCode(200);

        // Check if book is updated
        RestAssured.given()
                .when()
                .get("/" + newBook.getIsbn())
                .then()
                .statusCode(200)
                .and()
                .body("price", equalTo(59.99F));
    }

    @Test
    public void testSearchBook() {
        // Add a new book
        Book newBook = new Book("231314914", "Test User", "Software Architecture", 49.9);
        RestAssured.given()
                .contentType("application/json")
                .body(newBook)
                .when()
                .post("")
                .then()
                .statusCode(201);
        // Search book
        RestAssured.given()
                .when()
                .get("/search?author=" + newBook.getAuthor())
                .then()
                .statusCode(200)
                .and()
                .body("isbn", equalTo(newBook.getIsbn()))
                .body("author", equalTo(newBook.getAuthor()))
                .body("title", equalTo(newBook.getTitle()));
    }

}
